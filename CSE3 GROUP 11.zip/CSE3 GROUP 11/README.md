# airline-ticketing-js


Tools and technologies used
1. HTML
2. CSS
3. Bootstrap
4. Sweet Alerts
5. JavaScript

Deployed on heroku : https://comakeairlines.herokuapp.com/

Authors:
@Sahithi-Siripuram
@crax-kumar
@HarikaSree22
@bhavanisathi08
@SivaKumarK1

Key features:
1. Fully responsive
2. Validation for almost all input fields

Future improvements(frontend):
1. print another table with the initial details flightid, class no of passengers along with passenger details on click of submit button
2. add icons to the app
3. add a cursive font to the logo to make it look a little different than other fonts
4. add admin panal 
5. add validation to almost all 
6. add add passenger and delete passender options to bookiflight.html after submit option

Future improvements (backend)
1. add login, signup link to database
2. store the data in bookflight into the database after booking is confirmed 
3. access data from the database and display in myflight.html
4. add private routes to all pages to prevent displaying content before login
